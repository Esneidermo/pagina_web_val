# Change Logs

## v0.0.6

 - fix `_g-*` for only-child scenario


## v0.0.5

 - add `_g-*` for partially flexbox gap polyfill


## v0.0.4

 - add `style` field in `package.json`
 - upgrade modules
 - release with compact directory structure


## v0.0.3

 - add `g-*` for  `gap` of flexbox and grid layout.


## v0.0.2

 - scriptLoader (libLoader) is moved to `@plotdb/srcbuild`, we still support it but will use libLoader instead if found


